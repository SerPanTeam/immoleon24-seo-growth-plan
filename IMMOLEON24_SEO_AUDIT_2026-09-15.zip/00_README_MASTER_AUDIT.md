# IMMOLEON24 — Master SEO Audit

Date: 2026-09-15. Sources: Screaming Frog export (221 HTML URLs, 432 CSV files), archived DataForSEO runs dated 2026-09-11, and repository audit dossiers.

## Executive answer

The growth ceiling is not a lack of pages. It is fragmented intent ownership, weak broad-Düsseldorf authority, slow first-load experience, insufficient fresh third-party corroboration, and no supplied query-to-lead measurement. Benrath is the strongest local asset (Maps #2 in the archived tests), while broad Düsseldorf commercial queries were outside the organic and Maps Top 100 in the tested set.

## Why the site is not Top 3

1. Three indexable Düsseldorf makler pages compete for substantially overlapping intent. Similar duplicates exist for Hilden, Mettmann and Neuss.
2. Commercial seller and valuation architecture is weaker than the volume of informational posts; several articles target close valuation/seller terms without one unambiguous hub owner.
3. Homepage PSI in the supplied crawl is 65 with ~7.0s lab LCP; the earlier Lighthouse run measured 28/100, LCP ~7.1s and CLS 0.608.
4. Review quality is excellent (5.0), but the archived comparison showed only 20 reviews and low owner-response density versus 100+ reviews and ~90–100% replies among local leaders.
5. Local proof and machine-readable entity connections are not systematic enough across city/service/case/team entities.

## Highest-value geography

Tier A: Düsseldorf and Benrath. Tier B: Hilden, Mettmann, Neuss, Ratingen, Meerbusch, Erkrath and Kaarst, subject to service-area reality and SERP validation. Tier C: Dormagen, Solingen, Langenfeld and other proven-service locations. Pempelfort/Oberkassel should be covered by genuine district evidence, not doorway templates. Population, office distance and transaction volume are marked DATA NOT AVAILABLE because no authoritative dataset was supplied.

## Governance

Never create fake offices or cloned city text. Every new local URL requires distinct SERP intent, real service relevance, unique proof, maintainable market data, and a defined owner in the keyword map. Use one stable RealEstateAgent @id for the actual agency and Service.areaServed for service-area cities.

## Measurement gap

The Screaming Frog Search Console export does not contain clicks, impressions, CTR or query rows. GA4/CRM lead data was not supplied. Before forecasting leads or proving cannibalization, export GSC query×page for 16 months and connect calls/forms/valuation appointments/mandates to GA4 or the CRM.

## Deliverables

The directory contains 18 audit tables matching the requested workstreams. Numeric external metrics appear only where present in DataForSEO; all unknowns remain DATA NOT AVAILABLE.
