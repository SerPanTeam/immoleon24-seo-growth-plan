# IMMOLEON24 — полный SEO-аудит и практический план роста

Дата среза: 15.09.2026. Фактические источники: 432 CSV Screaming Frog (crawl 15.09.2026), 20 архивных DataForSEO-прогонов от 11.09.2026, включая Google Organic, Maps, Labs, Backlinks и LLM-проверки. GSC query/click/impression и GA4/CRM-конверсии не были переданы — соответствующие поля помечены `DATA NOT AVAILABLE`.

## Ответы на 13 главных вопросов

1. **Почему нет большего organic traffic:** сайт распределяет коммерческую релевантность между дублями local money pages, имеет слабую видимость по широкому Düsseldorf intent, медленный первый экран, недостаточно сильный локальный proof/citation layer и много контента без единого conversion ownership.
2. **Почему нет TOP-3:** в архивном Live SERP сайт не вошёл в TOP-100 по восьми широким Düsseldorf money queries; Benrath был около #39 organic, хотя Maps — #2. Google видит сильную микро-локальную сущность, но не лидера всего Düsseldorf.
3. **Где потенциал:** Tier A — Düsseldorf и Benrath. Tier B — Hilden, Mettmann, Neuss, Ratingen, Meerbusch, Erkrath, Kaarst. Tier C — Dormagen, Solingen, Langenfeld и другие реально обслуживаемые зоны после проверки спроса и уникального proof.
4. **Что усиливать:** `/immobilie-bewerten`, `/immobilie-verkaufen`, выбранный основной Düsseldorf makler URL, сильнейшие city pages, references/case studies и seller guides.
5. **Что создать:** сначала Düsseldorf pages для Haus verkaufen, Wohnung verkaufen и Immobilienbewertung — только после SERP-overlap; затем seller life-event cluster, price hub и доказанные Tier B pages.
6. **Что объединить:** три Düsseldorf makler pages; пары Hilden, Mettmann и Neuss; близкие valuation articles вокруг одного service hub. Решение — после GSC query×page и SERP overlap, а не по URL alone.
7. **Что noindex/delete:** `?__yPage=1` duplicates, неценные parameter/facet combinations, thin/empty archives. 404 YouTube URLs не перенаправлять как реальные страницы — исправить общий href, затем удалить внутренние ссылки.
8. **Что быстрее попадёт в TOP-10:** страницы с уже существующей релевантностью/authority и понятным коммерческим owner: valuation, Düsseldorf makler, city pages с ranking footprint, плюс title/H1/internal-link quick wins. Точный список требует GSC impressions, которых нет.
9. **Где traffic у конкурентов:** seller head terms, valuation, price content, calculators/checklists, digital owner tools, stronger local reviews and citations. DataForSEO gap rows находятся в `04`/`05`; competitor benchmark — в `12`.
10. **Лучшие locality × service:** Düsseldorf × Immobilienbewertung/Haus verkaufen/Wohnung verkaufen/Immobilienmakler; Benrath × Makler/Bewertung/Verkauf; затем Tier B cities × Makler/Bewertung — при доказанном спросе.
11. **Schema gaps:** единый RealEstateAgent entity, Service links, areaServed, Person/ProfilePage, Article authorship, listing Offer/property graph и BreadcrumbList.
12. **Google/AI understanding:** связать Agency→Agent→Service→Place→Property→Case→Market Report стабильными `@id`, ссылками и видимыми фактами; публиковать датированные данные с источниками и методикой.
13. **Что даст owner leads:** valuation funnel, consolidation of city intent, seller pages, review engine, case-based local proof, better speed, and source→mandate analytics.

## TOP 10 QUICK WINS

1. Исправить относительный YouTube href, создающий 9 внутренних 404 URL.
2. Сжать и корректно размерить hero/LCP images; preload только фактического LCP asset.
3. Устранить CLS главной резервированием размеров и стабилизацией компонентов.
4. Выбрать один canonical Düsseldorf makler owner и обновить внутренние ссылки.
5. Развести intent `/immobilie-bewerten` и `/online-immobilienbewertung`.
6. Сократить массово длинные title templates и убрать повторный brand suffix.
7. Заполнить descriptions сначала на commercial/indexable pages.
8. Исправить `?__yPage=1` и правила indexability/canonical pagination.
9. Добавить точные ссылки из inheritance/divorce/price guides на valuation.
10. Отвечать на 100% новых GBP reviews и запустить milestone request flow.

## TOP 10 MONEY PAGES TO STRENGTHEN

1. `/immobilie-bewerten`
2. `/immobilie-verkaufen`
3. выбранный owner из `/immobilienmakler-duesseldorf`, `/makler-duesseldorf`, `/regionen/immobilienmakler-in-duesseldorf`
4. `/online-immobilienbewertung` как отдельный tool intent
5. `/immobilienmakler-hilden` после объединения дубля
6. `/immobilienmakler-mettmann` после объединения дубля
7. `/immobilienmakler-neuss` после объединения дубля
8. `/immobilienmakler-ratingen`
9. `/immobilienmakler-meerbusch`
10. `/immobilienmakler-dormagen`

## TOP 25 NEW PAGES

Полный список и content requirements находятся в `08_NEW_LOCATION_PAGES.csv`. Первые три — Haus verkaufen Düsseldorf, Wohnung verkaufen Düsseldorf и Immobilienbewertung Düsseldorf. Они не должны публиковаться до проверки Top-10 overlap с выбранной Düsseldorf makler page.

## TOP GEO EXPANSION

- Tier A: Düsseldorf, Benrath.
- Tier B: Hilden, Mettmann, Neuss, Ratingen, Meerbusch, Erkrath, Kaarst.
- Tier C: Dormagen, Solingen, Langenfeld; districts only with demand and local proof.
- Tier D: small villages — no standalone template pages; cover in regional hubs unless demand and unique evidence justify a URL.

## TOP CONTENT GAPS

Haus/Wohnung verkaufen Düsseldorf, source-backed Immobilienpreise Düsseldorf, Haus mit Nießbrauch, vermietete Wohnung, verkaufen und wohnen bleiben, Unterlagen Hausverkauf, Maklerprovision, real Benrath/Düsseldorf sale cases and calculators.

## TOP TECHNICAL FIXES

Broken YouTube template link; homepage LCP/CLS; render-blocking resources; image delivery; metadata templates; pagination/facets; internal redirects; canonical/indexability/sitemap consistency; structured data templates; security headers.

## TOP SCHEMA FIXES

One real `RealEstateAgent` entity and stable `@id`; `Service.provider` and `areaServed`; no fake office addresses; `ProfilePage`/`Person`; `Article` author/date; listing `RealEstateListing` + `Offer` + actual property type; breadcrumbs matching site architecture.

## TOP INTERNAL LINKS

Exact source/target/anchor/placement rows are in `11_INTERNAL_LINKING.csv`. The governing rule is: every informational seller page leads to the matching valuation/sale page, every city page leads to its services/prices/references, and each proof page links back to the money owner.

## TOP BACKLINK OPPORTUNITIES

The strict five-competitor intersection returned only `immobilienscout24.de` and `maklersieger.de`; it is too strict to represent the full market. The prospecting layer prioritizes Düsseldorf/regional media, associations, chamber/partner ecosystems, map citations and data-led editorials. Every candidate marked recommendation must be verified before outreach.

## PRIORITY-BASED ROADMAP

- Foundation: access, measurement baseline, Ynfinite capability review and keyword-to-URL mapping.
- Technical: critical crawl/indexation fixes, redirect and canonical rules, performance and validation.
- Commercial: strengthen valuation and seller pages, resolve city-page overlap only after GSC/SERP/backlink checks.
- Expansion: publish validated seller, price and local pages with real evidence; build citations, links and repeat comparable Maps/SERP/AI benchmarks.

## Acceptance principle

Success is not “more indexed URLs”. It is one clear page owner per intent, no doorway templates, faster mobile experience, stronger Maps/organic/AI presence, and measurable movement from query → call/form → valuation appointment → mandate → deal.
