# Google Search Console export — immoleon24.com — 2026-09-18

## Access

Verified read access to the domain property `sc-domain:immoleon24.com` in Google Search Console. No GSC settings or filters were changed permanently.

## Exported files

### 01_GSC_WEB_16_MONTHS_2026-09-18.xlsx

Maximum standard Web Search performance range available in the UI:

- period: 2025-05-16 through 2026-09-15;
- total clicks: 1,378;
- total impressions: 140,749 (UI rounds this to 141K);
- average CTR: approximately 1.0%;
- average position: 31.2.

Sheets and data volume:

- `Диаграмма`: 488 daily rows;
- `Запросы`: 1,000 query rows (GSC UI export cap);
- `Страницы`: 425 URL rows;
- `Страны`: 185 country rows;
- `Устройства`: mobile, desktop, tablet;
- `Вид в поиске`: search appearance data;
- `Фильтры`: Web, last 16 months.

### 02_GSC_AI_FEATURES_MAX_AVAILABLE_2026-09-18.xlsx

The 16-month filter was selected, but Google currently exposes AI-feature data only from 2026-05-18 through 2026-09-15:

- total AI-feature impressions: 2,281;
- 121 daily rows;
- 65 URL rows;
- 29 country rows;
- mobile: 1,548 impressions;
- desktop: 655 impressions;
- tablet: 78 impressions.

Top AI-visible pages:

1. `/regionen/immobilienmakler-in-hilden` — 791 impressions;
2. `/regionen/immobilienmakler-in-bonn` — 373;
3. `/regionen/immobilienmakler-in-erkrath` — 353;
4. `/aktuelles/schenkung-immobilie-zu-lebzeiten` — 193;
5. `/regionen/immobilienmakler-in-mettmann` — 127.

## Immediate observations

- GSC reports the homepage separately as `http://www.immoleon24.com/` (443 clicks, 35,135 impressions, position 4.69) and `https://www.immoleon24.com/` (324 clicks, 19,577 impressions, position 40.65). This requires canonical/redirect/history investigation before combining the rows.
- High-impression commercial quick wins include Benrath, Urdenbach, Garath, Hassels and Reisholz queries currently averaging positions 4–8 but receiving very low CTR.
- The valuation query `immobilienbewertung kostenlos sofort ohne email` has 1,686 impressions, 38 clicks, 2.25% CTR and average position 8.31.
- AI visibility is concentrated in local Hilden/Bonn/Erkrath/Mettmann pages; 67.9% of AI impressions are mobile (1,548 of 2,281).

## Data-quality notes

- Search Console exports a maximum of 1,000 query rows in the UI, so the query sheet is not guaranteed to contain every low-volume query.
- AI-feature reporting currently contains impressions only, not clicks, CTR, queries or average position.
- An additional Image Search export was attempted after confirming 16 clicks, 8.53K impressions, 0.2% CTR and position 44.8, but the Chrome session switched to a service-authentication page before the file download completed. Video and News exports were therefore not collected in this pass.
- Raw exported values are preserved in the two `.xlsx` workbooks; no metric was invented or normalized.

