# IMMOLEON24 — что делать и что это даст

## Baseline до начала работ

- Проверено кандидатов: **469**.
- В исследованный стартовый набор вошла **281 фраза** с ненулевой частотностью; это не окончательный предел семантики.
- Нулевых/неизмеряемых: **188**, вынесены отдельно.
- В использованном DataForSEO Labs snapshot обнаружены ranking URL для **12** фраз; это не полный live rank tracking домена.
- Коммерческие кластеры с Business Value 9–10: **173 фразы**, сумма volume **143,860**. Сумма недедуплицирована: близкие формулировки могут описывать одну аудиторию.
- Production-расход финального успешного запуска: **$0.17772**. С учётом двух остановленных попыток весь расход текущей сессии составил **$0.82628**, что ниже лимита $1.60.

## Что ограничивает рост

В использованном DataForSEO Labs snapshot позиции обнаружены для 12 local Makler-фраз, лучшая обнаруженная позиция — #30. Для точных seller- и valuation-фраз ranking URL в snapshot не обнаружены. Это требует live SERP и GSC-проверки и не доказывает фактическое нахождение остальных фраз за TOP-100. Первичная задача — не публиковать сотни URL, а распределить запросы по целевым коммерческим страницам и подтвердить решения данными.

## Первые пять действий

1. Зафиксировать GSC/GA4/CRM baseline: иначе нельзя измерить заявки и доказать каннибализацию.
2. Удалить шаблонные 404 и исправить LCP/CLS: убрать техническое и конверсионное трение.
3. Проверить пересечение Düsseldorf Makler-страниц через GSC, SERP, ссылки и конверсии; объединять только после подтверждения.
4. Развести expert valuation и online tool: один путь к заявке, без конкурирующих статей.
5. Усилить Dormagen, Mettmann, Hilden, Langenfeld, Meerbusch, Kaarst и Erkrath — это единственные подтверждённые текущие organic footholds.

## Подтверждённые позиции

| Keyword | Volume | Position | URL |
|---|---:|---:|---|
| immobilienmakler dormagen | 590 | 30 | https://www.immoleon24.com/immobilienmakler-dormagen |
| makler dormagen | 210 | 30 | https://www.immoleon24.com/immobilienmakler-dormagen |
| immobilienmakler mettmann | 210 | 37 | https://www.immoleon24.com/immobilienmakler-mettmann |
| immobilienmakler langenfeld | 260 | 38 | https://www.immoleon24.com/immobilienmakler-langenfeld |
| makler kaarst | 70 | 38 | https://www.immoleon24.com/regionen/immobilienmakler-in-kaarst |
| immobilienmakler kaarst | 210 | 41 | https://www.immoleon24.com/regionen/immobilienmakler-in-kaarst |
| makler hilden | 140 | 41 | https://www.immoleon24.com/immobilienmakler-hilden |
| immobilienmakler hilden | 390 | 42 | https://www.immoleon24.com/immobilienmakler-hilden |
| makler meerbusch | 320 | 43 | https://www.immoleon24.com/immobilienmakler-meerbusch |
| makler langenfeld | 70 | 43 | https://www.immoleon24.com/immobilienmakler-langenfeld |
| makler mettmann | 70 | 44 | https://www.immoleon24.com/immobilienmakler-mettmann |
| immobilienmakler erkrath | 110 | 47 | https://www.immoleon24.com/regionen/immobilienmakler-in-erkrath |

## Как читать файлы

- `01`: только ненулевое ядро с volume, CPC, competition, KD, текущей позицией и ranking URL.
- `02`: нулевые/неизмеряемые фразы; они не участвовали в baseline positions.
- `03`: кластерные суммы и текущий захват.
- `04`: последовательный implementation plan с ожидаемым эффектом и acceptance criteria.

Позиции — DataForSEO Labs Germany/de exact-keyword snapshot. Дата SERP внутри каждой строки может отличаться и указана в поле `SERP Checked At`; это baseline базы DataForSEO, а не персонализированная ручная выдача из Düsseldorf. Для 10–20 самых важных запросов рекомендуется отдельный fixed-location Live SERP benchmark после утверждения целевых URL.
